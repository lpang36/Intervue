'use strict';

const Alexa = require('alexa-sdk');
var http = require('http');
var https = require('https');
const user = "John";
var util = require('util');
var qid = 0;

const APP_ID = 'amzn1.ask.skill.767ff4a2-1513-4028-a37b-1476f0317390';
var serviceHost = 'https://intervue.herokuapp.com';

var handlers = {
  'LaunchRequest': function() {
    param = "/question/"+user;
    self = this;
    callback = function(res,self) {
      var speech = res.question;
      qid = res.id;
      self.emit(":ask",speech);
    }
    httpGet(serviceHost,param,callback,self);
  },
  'QuestionIntent': function() {
    param = "/question/"+user;
    self = this;
    callback = function(res,self) {
      var speech = res.question;
      qid = res.id;
      self.emit(":ask",speech);
    }
    httpGet(serviceHost,param,callback,self);
  },
  'AnswerIntent': function(answer) {
    param = encodeURI("/"+answer+"/"+qid+"/"+user);
    self = this;
    callback = function(res,self) {
      var speech = res;
      self.emit(":tell",speech);
    }
    httpGet(serviceHost,param,callback,self);
  },
  'Unhandled': function () {
    this.emit(':ask', "sample message");
  }
};

exports.handler = function(event, context, callback){
  var alexa = Alexa.handler(event, context);
  alexa.registerHandlers(handlers);
  alexa.execute();
};

// Create a web request and handle the response.
function httpGet(url, urlData, callback, self) {
   console.log("url: "+ url);
   console.log("urlData: "+ urlData);
   console.log(url+urlData);
   var req = https.get(url+urlData, (res) => {
        console.log(res);
        console.log("RESPONSE");
        var body = '';
        res.on('data', (d) => {
            body += d;
        });
        res.on('end', (res) => {
        console.log("finished");
        callback(body,self);
        });
    }).on('error', function(e) {
        console.log("Got error: " + e.message);
    });
    req.end();
}